package com.agendaLive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaLiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaLiveApplication.class, args);
	}

}
